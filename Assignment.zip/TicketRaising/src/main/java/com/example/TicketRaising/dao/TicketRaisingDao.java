package com.example.TicketRaising.dao;

import com.example.TicketRaising.model.Tickets;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface TicketRaisingDao extends JpaRepository<Tickets,Integer> {

    @Query(value = "Select * from Ticket_Details t where t.title like %:keyword% or t.description like %:keyword%", nativeQuery = true)
    List<Tickets> findByQuery(@Param("keyword") String query);
}
