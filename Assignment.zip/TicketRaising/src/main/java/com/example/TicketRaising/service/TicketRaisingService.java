package com.example.TicketRaising.service;

import com.example.TicketRaising.model.Tickets;

import java.util.List;

public interface TicketRaisingService {

    List<Tickets> getAllTickets();

    Tickets findTicketsById(int id);

    void saveTickets(Tickets t);

    void deleteTickets(Tickets t);

    List<Tickets> getAllTicketsByQuery(String query);
}
