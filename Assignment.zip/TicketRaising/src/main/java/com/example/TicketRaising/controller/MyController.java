package com.example.TicketRaising.controller;


import com.example.TicketRaising.model.Tickets;
import com.example.TicketRaising.service.TicketRaisingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
public class MyController {

    @Autowired
    TicketRaisingService ticketRaisingService;

    Date date = new Date();

    @GetMapping({"/","/search"})
    public String getTickets(Model model, @RequestParam(value = "keyword", required = false) String query){
        if(query != null){
            List<Tickets> list = ticketRaisingService.getAllTicketsByQuery(query);
            model.addAttribute("query",query);
            model.addAttribute("list",list);
        }
        else{
            model.addAttribute("list",ticketRaisingService.getAllTickets());
        }
        return "home";

    }

    @GetMapping("/update/{id}")
    public String giveUpdationForm(@PathVariable("id") int id, Model model){
        Tickets t = ticketRaisingService.findTicketsById(id);
        model.addAttribute("ticket",t);
        return "updateform";
    }

    @GetMapping("/newTicket")
    public String newTicketForm(Model model){
        model.addAttribute("ticket",new Tickets());
        return "addTicket";
    }

    @GetMapping("/view/{id}")
    public String getTicketDetails(@PathVariable("id") int id, Model model){
        Tickets t = ticketRaisingService.findTicketsById(id);
        model.addAttribute("ticket",t);
        return "ticketview";
    }

    @PostMapping("/saveTicket")
    public String saveTicket(@ModelAttribute Tickets t){
        t.setDate(date);
        ticketRaisingService.saveTickets(t);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteTicket(@PathVariable("id") int id){
        Tickets t = ticketRaisingService.findTicketsById(id);
        ticketRaisingService.deleteTickets(t);
        return "redirect:/";
    }
}
